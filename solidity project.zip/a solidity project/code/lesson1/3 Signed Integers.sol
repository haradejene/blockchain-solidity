// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract Contract {
    int8 public a = 20;     
    int8 public b = -10;  

    int16 public difference = a - b; // 20 - (-10) = 30
}
