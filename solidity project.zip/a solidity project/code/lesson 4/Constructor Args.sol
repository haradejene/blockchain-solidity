// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "./Hero.sol";

contract Mage is Hero(50) {

    function attack(Enemy enemy) public override {
        enemy.takeAttack(AttackTypes.Spell);

        // call base logic
        super.attack(enemy);
    }
}

contract Warrior is Hero(200) {

    function attack(Enemy enemy) public override {
        enemy.takeAttack(AttackTypes.Brawl);

        // call base logic
        super.attack(enemy);
    }
}