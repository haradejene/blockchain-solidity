// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract Sidekick {

    function sendAlert(address hero, uint256 enemies, bool armed) external {
        bytes memory payload = abi.encodeWithSignature(
            "alert(uint256,bool)",
            enemies,
            armed
        );

        (bool success, ) = hero.call(payload);
        require(success, "call failed");
    }
}